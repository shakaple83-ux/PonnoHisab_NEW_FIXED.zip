# পণ্য হিসাব Android App

Firebase-connected Android app for product accounting.

Features:
- Firebase email/password authentication
- Product description, measurement/quantity, price and optional photo
- Total = measurement × price
- Grand total
- Firestore cloud data and Firebase Storage photos
- GitHub Actions APK build

The included `app/google-services.json` belongs to the Firebase Android app with package `com.example.ponnohisab`.
