package com.example.ponnohisab;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private Uri selectedImage;
    private final ArrayList<Product> products = new ArrayList<>();
    private ProductAdapter adapter;
    private TextView totalText;

    private final ActivityResultLauncher<String> pickImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                selectedImage = uri;
                toast(uri == null ? "ছবি নির্বাচন বাতিল" : "ছবি নেওয়া হয়েছে");
            });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        if (auth.getCurrentUser() == null) showLogin(); else showHome();
    }

    private LinearLayout box(int padding) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(padding, padding, padding, padding);
        return b;
    }

    private void showLogin() {
        LinearLayout root = box(36);
        TextView title = new TextView(this);
        title.setText("📦 পণ্য হিসাব"); title.setTextSize(30); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        EditText email = new EditText(this); email.setHint("ইমেইল / Username"); email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText pass = new EditText(this); pass.setHint("Password"); pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Button login = new Button(this); login.setText("লগইন");
        Button signup = new Button(this); signup.setText("নতুন অ্যাকাউন্ট তৈরি");
        root.addView(email); root.addView(pass); root.addView(login); root.addView(signup);
        setContentView(root);

        login.setOnClickListener(v -> {
            String e = email.getText().toString().trim(), p = pass.getText().toString();
            if (e.isEmpty() || p.isEmpty()) { toast("ইমেইল ও Password দিন"); return; }
            auth.signInWithEmailAndPassword(e, p).addOnSuccessListener(x -> showHome()).addOnFailureListener(x -> toast("লগইন হয়নি: " + x.getMessage()));
        });
        signup.setOnClickListener(v -> {
            String e = email.getText().toString().trim(), p = pass.getText().toString();
            if (e.isEmpty() || p.length() < 6) { toast("সঠিক Email এবং কমপক্ষে ৬ অক্ষরের Password দিন"); return; }
            auth.createUserWithEmailAndPassword(e, p).addOnSuccessListener(x -> showHome()).addOnFailureListener(x -> toast("অ্যাকাউন্ট তৈরি হয়নি: " + x.getMessage()));
        });
    }

    private void showHome() {
        LinearLayout root = box(16);
        LinearLayout bar = new LinearLayout(this); bar.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = new TextView(this); title.setText("📦 পণ্য হিসাব"); title.setTextSize(25);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button logout = new Button(this); logout.setText("লগআউট"); bar.addView(logout);
        root.addView(bar);

        Button add = new Button(this); add.setText("＋ নতুন পণ্য যোগ করুন"); root.addView(add);
        RecyclerView list = new RecyclerView(this); list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductAdapter(products); list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        totalText = new TextView(this); totalText.setTextSize(20); root.addView(totalText);
        setContentView(root);

        add.setOnClickListener(v -> showAddDialog());
        logout.setOnClickListener(v -> { auth.signOut(); showLogin(); });
        loadProducts();
    }

    private void loadProducts() {
        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();
        db.collection("users").document(uid).collection("products").get()
                .addOnSuccessListener(snap -> {
                    products.clear();
                    snap.getDocuments().forEach(d -> {
                        Product p = new Product(); p.id=d.getId(); p.description=d.getString("description");
                        Double m=d.getDouble("measurement"), pr=d.getDouble("price"); p.measurement=m==null?0:m; p.price=pr==null?0:pr; p.imageUrl=d.getString("imageUrl"); products.add(p);
                    });
                    adapter.notifyDataSetChanged(); updateTotal();
                }).addOnFailureListener(e -> toast("ডাটা লোড হয়নি: " + e.getMessage()));
    }

    private void updateTotal() {
        double sum=0; for(Product p:products) sum += p.measurement*p.price;
        totalText.setText(String.format(Locale.US, "💰 সর্বমোট টাকা: ৳%.2f", sum));
    }

    private void showAddDialog() {
        selectedImage=null; LinearLayout b=box(16);
        EditText desc=new EditText(this); desc.setHint("পণ্যের বিবরণ");
        EditText measure=new EditText(this); measure.setHint("পরিমাণ / মাপ"); measure.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText price=new EditText(this); price.setHint("পণ্যের দাম"); price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Button photo=new Button(this); photo.setText("📷 পণ্যের ছবি নির্বাচন"); photo.setOnClickListener(v -> pickImage.launch("image/*"));
        b.addView(desc); b.addView(measure); b.addView(price); b.addView(photo);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("নতুন পণ্য").setView(b).setNegativeButton("বাতিল",null).setPositiveButton("সেভ",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            Double m=parse(measure.getText().toString()), p=parse(price.getText().toString());
            if(desc.getText().toString().trim().isEmpty()||m==null||p==null){toast("সব তথ্য ঠিকভাবে দিন");return;}
            saveProduct(desc.getText().toString().trim(),m,p,dialog);
        }));
        dialog.show();
    }

    private Double parse(String s){try{return Double.parseDouble(s);}catch(Exception e){return null;}}

    private void saveProduct(String desc,double measure,double price,AlertDialog dialog){
        String uid=auth.getCurrentUser().getUid();
        DocumentReference ref=db.collection("users").document(uid).collection("products").document();
        if(selectedImage==null){writeProduct(ref,desc,measure,price,"");dialog.dismiss();return;}
        StorageReference imageRef=storage.getReference().child("users/"+uid+"/products/"+ref.getId()+".jpg");
        imageRef.putFile(selectedImage).continueWithTask(t -> imageRef.getDownloadUrl()).addOnSuccessListener(url->{writeProduct(ref,desc,measure,price,url.toString());dialog.dismiss();}).addOnFailureListener(e->toast("ছবি আপলোড হয়নি: "+e.getMessage()));
    }

    private void writeProduct(com.google.firebase.firestore.DocumentReference ref,String desc,double measure,double price,String url){
        Map<String,Object> data=new HashMap<>(); data.put("description",desc);data.put("measurement",measure);data.put("price",price);data.put("imageUrl",url);
        ref.set(data).addOnSuccessListener(x->{toast("পণ্য সেভ হয়েছে");loadProducts();}).addOnFailureListener(e->toast("সেভ হয়নি: "+e.getMessage()));
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    static class Product { String id="",description="",imageUrl=""; double measurement=0,price=0; }

    static class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.VH>{
        final ArrayList<Product> items; ProductAdapter(ArrayList<Product> items){this.items=items;}
        static class VH extends RecyclerView.ViewHolder{TextView t;VH(TextView v){super(v);t=v;}}
        @Override public VH onCreateViewHolder(android.view.ViewGroup p,int t){TextView v=new TextView(p.getContext());v.setTextSize(17);v.setPadding(20,22,20,22);return new VH(v);}
        @Override public int getItemCount(){return items.size();}
        @Override public void onBindViewHolder(VH h,int pos){Product x=items.get(pos);h.t.setText(String.format(Locale.US,"%d. %s\nপরিমাণ/মাপ: %.2f   দাম: ৳%.2f\nমোট টাকা: ৳%.2f",pos+1,x.description,x.measurement,x.price,x.measurement*x.price));}
    }
}
